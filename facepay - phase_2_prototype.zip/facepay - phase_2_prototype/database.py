from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    bank_name = db.Column(db.String(100), nullable=True)
    account_number = db.Column(db.String(20), nullable=True)
    sort_code = db.Column(db.String(10), nullable=True)
    card_name = db.Column(db.String(100), nullable=True)
    card_token = db.Column(db.String(255), nullable=True)
    face_image = db.Column(db.LargeBinary, nullable=False)

