from flask import Flask, request, redirect, url_for, render_template, session, jsonify
from database import db, User
from base64 import b64decode
import face_recognition
import stripe
from io import BytesIO
from PIL import Image
import numpy as np
import base64

# Generate a secure random key
def generate_secret_key():
    random_bytes = np.random.bytes(24)  # Generate 24 random bytes
    secret_key = base64.b64encode(random_bytes).decode("utf-8")  # Encode as Base64
    return secret_key

app = Flask(__name__)
app.secret_key = generate_secret_key()

# Configure Stripe
stripe.api_key = "sk_test_51Q2ZGH055NWWURZmblCVBBHs71JCpyl72q8bb8r7bGGr4PfNWITfHwjjYrhuLXvWHbwjAh0HQkuOS1Ojo8I0lapL00qPg47n7K"  # Replace with your Stripe secret key

# Configure SQLite database
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///new_user_data.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Ensure the new database is created
with app.app_context():
    db.create_all()

@app.route("/", methods=["GET"])
def home():
    """Home page with Register and Login options."""
    return render_template("home.html")

@app.route("/user_details", methods=["GET", "POST"])
def user_details():
    """User details form for registration."""
    if request.method == "POST":
        session["name"] = request.form["name"]
        session["email"] = request.form["email"]
        session["password"] = request.form["password"]
        return redirect(url_for("bank_card_details"))
    return render_template("user_details.html")

@app.route("/bank_card_details", methods=["GET", "POST"])
def bank_card_details():
    """Form to add bank and card details for registration."""
    if request.method == "POST":
        session["bank_name"] = request.form.get("bankName")
        session["account_number"] = request.form.get("accountNumber")
        session["sort_code"] = request.form.get("sortCode")
        card_name = request.form.get("cardName")
        card_number = request.form.get("cardNumber")
        exp_date = request.form.get("expDate")

        # Use Stripe's test token for card storage
        session["card_token"] = "tok_visa"  # Replace with other test tokens for different cards if needed
        session["card_name"] = card_name

        return redirect(url_for("face_capture"))

    return render_template("bank_card_details.html")

@app.route("/face_capture", methods=["GET", "POST"])
def face_capture():
    """Face capture form and final submission."""
    if request.method == "POST":
        try:
            face_image = request.form["faceImage"]

            new_user = User(
                name=session["name"],
                email=session["email"],
                password=session["password"],
                bank_name=session.get("bank_name"),
                account_number=session.get("account_number"),
                sort_code=session.get("sort_code"),
                card_name=session.get("card_name"),
                card_token=session.get("card_token"),  # Store the tokenized card
                face_image=b64decode(face_image.split(",")[1]),
            )
            db.session.add(new_user)
            db.session.commit()

            return render_template("success.html", name=session["name"])

        except Exception as e:
            print(f"Error: {e}")
            return "Registration failed. Please try again.", 500

    return render_template("face_capture.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page to authenticate users."""
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        # Validate user credentials
        user = User.query.filter_by(email=email, password=password).first()
        if user:
            session["user_id"] = user.id
            session["name"] = user.name
            return redirect(url_for("payment_options"))
        else:
            return "Invalid credentials. Please try again.", 401

    return render_template("login.html")

@app.route("/payment_options", methods=["GET", "POST"])
def payment_options():
    """Display saved payment options for the user."""
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))

    user = User.query.get(user_id)
    if not user:
        return "User not found", 404

    if request.method == "POST":
        session["selected_payment"] = request.form["payment_option"]
        return redirect(url_for("capture_face"))

    return render_template(
        "payment_options.html",
        name=user.name,
        bank_details={
            "bank_name": user.bank_name,
            "account_number": user.account_number,
            "sort_code": user.sort_code,
        } if user.bank_name else None,
        card_details={
            "card_name": user.card_name,
            "token": user.card_token,  # Use the tokenized card
        } if user.card_name else None,
    )

@app.route("/capture_face", methods=["GET", "POST"])
def capture_face():
    """Capture and verify the face of the user."""
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))

    user = User.query.get(user_id)
    if not user:
        return "User not found", 404

    if request.method == "POST":
        try:
            face_image = request.form["faceImage"]

            # Decode the captured face image
            captured_face_data = b64decode(face_image.split(",")[1])
            captured_face_image = Image.open(BytesIO(captured_face_data)).convert("RGB")
            captured_face_array = np.array(captured_face_image)

            # Load the stored face image from the database
            stored_face_image = Image.open(BytesIO(user.face_image)).convert("RGB")
            stored_face_array = np.array(stored_face_image)

            # Encode the face images using face_recognition
            captured_encodings = face_recognition.face_encodings(captured_face_array)
            stored_encodings = face_recognition.face_encodings(stored_face_array)

            # Check if encodings are available
            if not captured_encodings or not stored_encodings:
                return "Face detection failed. Ensure your face is visible in the frame.", 400

            # Compare the face encodings
            match = face_recognition.compare_faces([stored_encodings[0]], captured_encodings[0])

            if not match[0]:
                return "Face verification failed. Payment cannot proceed.", 401

            return redirect(url_for("process_payment"))

        except Exception as e:
            print(f"Error: {e}")
            return "An error occurred during face verification.", 500

    return render_template("capture_face.html")

@app.route("/process_payment", methods=["GET", "POST"])
def process_payment():
    """Process payment after face verification."""
    user_id = session.get("user_id")
    if not user_id:
        return redirect(url_for("login"))

    user = User.query.get(user_id)
    if not user:
        return "User not found", 404

    payment_option = session.get("selected_payment")
    if not payment_option:
        return "No payment option selected.", 400

    amount = 1000  # Amount in cents ($10.00)
    try:
        if payment_option == "card":
            if not user.card_token:
                return "Card token not available.", 400

            # Process payment using Stripe's test token
            stripe.Charge.create(
                amount=amount,
                currency="usd",
                source=user.card_token,
                description=f"Payment by {user.name}",
            )

            return render_template("verify_success.html", name=user.name, amount=amount / 100)

        elif payment_option == "bank":
            if not user.bank_name:
                return "Bank details not available.", 400

            # Placeholder for bank payment integration
            return jsonify({"message": "Bank payment not implemented"}), 501

    except stripe.error.StripeError as e:
        print(f"Stripe Error: {e}")
        return "Payment failed. Please try again later.", 500
    
@app.route("/thank_you", methods=["GET"])
def thank_you():
    """Page to display a final thank-you message."""
    return render_template("thank_you.html")



if __name__ == "__main__":
    app.run(debug=True) 